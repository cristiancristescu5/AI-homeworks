package org.example;


import org.example.Game.Game;
import org.example.State.State;

public class Main {
    public static void main(String[] args) {
        Game.run();
    }
}