package org.example;

public enum Direction {
    TOP, DOWN, LEFT, RIGHT, NONE
}
